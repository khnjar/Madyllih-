package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "saved_prescriptions")
data class SavedPrescription(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val condition: String,
    val regimen: String,
    val duration: String,
    val monitoring: String,
    val isCustom: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
) : Serializable

@Entity(tableName = "calculation_logs")
data class CalculationLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val patientName: String,
    val modelUsed: String, // "Framingham" or "CHA₂DS₂-VASc" or "eGFR"
    val inputsSummary: String, // Short summary of inputs like "M, 54, SBP: 140, Chol: 200, Smoker"
    val calculatedResult: String, // e.g., "12.5% (Medium Risk)" or "Stage 3 (eGFR: 45)"
    val scoreText: String, // Raw score or index
    val createdAt: Long = System.currentTimeMillis()
) : Serializable

@Entity(tableName = "bookmarked_topics")
data class BookmarkedTopic(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val topicType: String, // "system" or "article" or "hadith" or "prediction"
    val topicId: String, // system id or article id
    val topicTitle: String,
    val createdAt: Long = System.currentTimeMillis()
) : Serializable

@Entity(tableName = "body_systems")
data class BodySystemEntity(
    @PrimaryKey val id: String,
    val name: String,
    val latinName: String,
    val icon: String,
    val scientificDescription: String,
    val relevantHadith: String,
    val mechanism: String,
    val createdAt: Long = System.currentTimeMillis()
) : Serializable

@Entity(tableName = "quiz_results")
data class QuizResultEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val systemId: String,
    val systemTitle: String,
    val score: Int,
    val totalQuestions: Int,
    val percentage: Int,
    val feedback: String,
    val createdAt: Long = System.currentTimeMillis()
) : Serializable

@Entity(tableName = "medical_articles")
data class MedicalArticleEntity(
    @PrimaryKey val id: String,
    val title: String,
    val category: String, // e.g., "أمراض القلب", "العلوم الفسيولوجية", "المناعة والعدوى", "الكلى والإخراج", "الطب النبوي والتكامل"
    val summary: String,
    val fullContent: String,
    val physiologicalMechanism: String,
    val keyStats: String, // "معدل الانتشار: 15% | نسبة النجاح: 92% | الخطر المستقبلي: 8%"
    val evidenceLevel: String, // "Level 1A - أدلة سريرية محكمة"
    val recommendations: String, // توصيات وإرشادات للتشخيص والمتابعة
    val authorReference: String, // Harrison's / Lancet / UBIS Medical Journal
    val readTimeMinutes: Int = 5,
    val createdAt: Long = System.currentTimeMillis()
) : Serializable

@Entity(tableName = "prophetic_hadiths")
data class HadithEntity(
    @PrimaryKey val id: String,
    val hadithText: String,
    val narrationSource: String, // e.g. "صحيح البخاري رقم 6011 - صحيح مسلم رقم 2586"
    val narrator: String, // e.g. "عن النعمان بن بشير رضي الله عنهما"
    val title: String, // e.g. "حديث تداعي الجسد بالسهر والحمى"
    val medicalSignificance: String, // الشرح والتحليل الطبي الفسيولوجي
    val organConnections: String, // "القلب - الدماغ - جهاز المناعة - تنظيم الحرارة"
    val modernPhysiologyParallel: String, // الربط مع أحدث الدراسات الطبية في استجابة السيتوكينات
    val createdAt: Long = System.currentTimeMillis()
) : Serializable

@Entity(tableName = "patient_vitals_records")
data class PatientVitalRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val patientName: String,
    val systolicBp: Int,
    val diastolicBp: Int,
    val heartRate: Int,
    val bloodGlucose: Double,
    val oxygenSat: Int,
    val temperature: Double,
    val riskAssessment: String,
    val aiRecommendation: String,
    val recordedAt: Long = System.currentTimeMillis()
) : Serializable
