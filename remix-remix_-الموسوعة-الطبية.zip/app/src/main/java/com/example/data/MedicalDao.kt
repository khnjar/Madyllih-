package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MedicalDao {
    // Prescriptions
    @Query("SELECT * FROM saved_prescriptions ORDER BY createdAt DESC")
    fun getAllPrescriptions(): Flow<List<SavedPrescription>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrescription(prescription: SavedPrescription)

    @Delete
    suspend fun deletePrescription(prescription: SavedPrescription)

    @Query("DELETE FROM saved_prescriptions WHERE id = :id")
    suspend fun deletePrescriptionById(id: Int)

    // Calculation Logs
    @Query("SELECT * FROM calculation_logs ORDER BY createdAt DESC")
    fun getAllCalculationLogs(): Flow<List<CalculationLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCalculationLog(log: CalculationLog)

    @Delete
    suspend fun deleteCalculationLog(log: CalculationLog)

    @Query("DELETE FROM calculation_logs WHERE id = :id")
    suspend fun deleteCalculationLogById(id: Int)

    // Bookmarked Topics
    @Query("SELECT * FROM bookmarked_topics ORDER BY createdAt DESC")
    fun getAllBookmarks(): Flow<List<BookmarkedTopic>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBookmark(bookmark: BookmarkedTopic)

    @Query("DELETE FROM bookmarked_topics WHERE topicType = :type AND topicId = :topicId")
    suspend fun deleteBookmark(type: String, topicId: String)

    @Query("SELECT EXISTS(SELECT * FROM bookmarked_topics WHERE topicType = :type AND topicId = :topicId)")
    fun isBookmarked(type: String, topicId: String): Flow<Boolean>

    // Body Systems
    @Query("SELECT * FROM body_systems ORDER BY createdAt DESC")
    fun getAllBodySystems(): Flow<List<BodySystemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBodySystem(system: BodySystemEntity)

    @Delete
    suspend fun deleteBodySystem(system: BodySystemEntity)

    @Query("SELECT * FROM body_systems WHERE id = :id LIMIT 1")
    suspend fun getBodySystemById(id: String): BodySystemEntity?

    // Quiz Results
    @Query("SELECT * FROM quiz_results ORDER BY createdAt DESC")
    fun getAllQuizResults(): Flow<List<QuizResultEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuizResult(result: QuizResultEntity)

    @Query("DELETE FROM quiz_results WHERE id = :id")
    suspend fun deleteQuizResultById(id: Int)

    // Medical Articles (Local Room Storage)
    @Query("SELECT * FROM medical_articles ORDER BY createdAt DESC")
    fun getAllArticles(): Flow<List<MedicalArticleEntity>>

    @Query("SELECT * FROM medical_articles WHERE title LIKE '%' || :query || '%' OR summary LIKE '%' || :query || '%' OR fullContent LIKE '%' || :query || '%' OR category LIKE '%' || :query || '%' ORDER BY createdAt DESC")
    fun searchArticles(query: String): Flow<List<MedicalArticleEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertArticles(articles: List<MedicalArticleEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertArticle(article: MedicalArticleEntity)

    @Query("DELETE FROM medical_articles WHERE id = :id")
    suspend fun deleteArticleById(id: String)

    // Prophetic Hadiths (Local Room Storage)
    @Query("SELECT * FROM prophetic_hadiths ORDER BY createdAt DESC")
    fun getAllHadiths(): Flow<List<HadithEntity>>

    @Query("SELECT * FROM prophetic_hadiths WHERE hadithText LIKE '%' || :query || '%' OR medicalSignificance LIKE '%' || :query || '%' OR title LIKE '%' || :query || '%' ORDER BY createdAt DESC")
    fun searchHadiths(query: String): Flow<List<HadithEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHadiths(hadiths: List<HadithEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHadith(hadith: HadithEntity)

    @Query("DELETE FROM prophetic_hadiths WHERE id = :id")
    suspend fun deleteHadithById(id: String)

    // Patient Vital Records
    @Query("SELECT * FROM patient_vitals_records ORDER BY recordedAt DESC")
    fun getAllPatientRecords(): Flow<List<PatientVitalRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPatientRecord(record: PatientVitalRecordEntity)

    @Query("DELETE FROM patient_vitals_records WHERE id = :id")
    suspend fun deletePatientRecordById(id: Int)
}
