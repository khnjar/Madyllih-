package com.example.data

import kotlinx.coroutines.flow.Flow

class MedicalRepository(private val medicalDao: MedicalDao) {
    // Existing Flows
    val allPrescriptions: Flow<List<SavedPrescription>> = medicalDao.getAllPrescriptions()
    val allCalculationLogs: Flow<List<CalculationLog>> = medicalDao.getAllCalculationLogs()
    val allBookmarks: Flow<List<BookmarkedTopic>> = medicalDao.getAllBookmarks()
    val allBodySystems: Flow<List<BodySystemEntity>> = medicalDao.getAllBodySystems()
    val allQuizResults: Flow<List<QuizResultEntity>> = medicalDao.getAllQuizResults()

    // New Local Room Flows for Articles, Hadiths, and Patient Records
    val allArticles: Flow<List<MedicalArticleEntity>> = medicalDao.getAllArticles()
    val allHadiths: Flow<List<HadithEntity>> = medicalDao.getAllHadiths()
    val allPatientRecords: Flow<List<PatientVitalRecordEntity>> = medicalDao.getAllPatientRecords()

    suspend fun insertPrescription(prescription: SavedPrescription) {
        medicalDao.insertPrescription(prescription)
    }

    suspend fun deletePrescriptionById(id: Int) {
        medicalDao.deletePrescriptionById(id)
    }

    suspend fun insertCalculationLog(log: CalculationLog) {
        medicalDao.insertCalculationLog(log)
    }

    suspend fun deleteCalculationLogById(id: Int) {
        medicalDao.deleteCalculationLogById(id)
    }

    suspend fun insertBookmark(bookmark: BookmarkedTopic) {
        medicalDao.insertBookmark(bookmark)
    }

    suspend fun deleteBookmark(type: String, topicId: String) {
        medicalDao.deleteBookmark(type, topicId)
    }

    fun isBookmarked(type: String, topicId: String): Flow<Boolean> {
        return medicalDao.isBookmarked(type, topicId)
    }

    suspend fun insertBodySystem(system: BodySystemEntity) {
        medicalDao.insertBodySystem(system)
    }

    suspend fun deleteBodySystem(system: BodySystemEntity) {
        medicalDao.deleteBodySystem(system)
    }

    suspend fun getBodySystemById(id: String): BodySystemEntity? {
        return medicalDao.getBodySystemById(id)
    }

    suspend fun insertQuizResult(result: QuizResultEntity) {
        medicalDao.insertQuizResult(result)
    }

    suspend fun deleteQuizResultById(id: Int) {
        medicalDao.deleteQuizResultById(id)
    }

    // Article Room Operations
    fun searchArticles(query: String): Flow<List<MedicalArticleEntity>> {
        return if (query.isBlank()) medicalDao.getAllArticles() else medicalDao.searchArticles(query)
    }

    suspend fun insertArticle(article: MedicalArticleEntity) {
        medicalDao.insertArticle(article)
    }

    suspend fun insertArticles(articles: List<MedicalArticleEntity>) {
        medicalDao.insertArticles(articles)
    }

    suspend fun deleteArticleById(id: String) {
        medicalDao.deleteArticleById(id)
    }

    // Hadith Room Operations
    fun searchHadiths(query: String): Flow<List<HadithEntity>> {
        return if (query.isBlank()) medicalDao.getAllHadiths() else medicalDao.searchHadiths(query)
    }

    suspend fun insertHadith(hadith: HadithEntity) {
        medicalDao.insertHadith(hadith)
    }

    suspend fun insertHadiths(hadiths: List<HadithEntity>) {
        medicalDao.insertHadiths(hadiths)
    }

    suspend fun deleteHadithById(id: String) {
        medicalDao.deleteHadithById(id)
    }

    // Patient Vital Records Operations
    suspend fun insertPatientRecord(record: PatientVitalRecordEntity) {
        medicalDao.insertPatientRecord(record)
    }

    suspend fun deletePatientRecordById(id: Int) {
        medicalDao.deletePatientRecordById(id)
    }
}
