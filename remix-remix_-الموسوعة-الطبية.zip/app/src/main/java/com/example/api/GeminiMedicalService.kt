package com.example.api

import com.example.BuildConfig
import com.example.data.MedicalRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class GeminiMedicalService(private val repository: MedicalRepository) {

    suspend fun getPhysiologicalInterpretationWithLocalDb(userQuery: String): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext "تنبيه: مفتاح Gemini API غير معرف بعد. يرجى إضافة مفتاحك عبر لوحة الأسرار (Secrets Panel) في AI Studio لتمكين ربط الخدمة بـ Retrofit."
        }

        // 1. Fetch relevant context from local Room Database
        val localArticles = repository.allArticles.first()
        val localHadiths = repository.allHadiths.first()

        val matchingArticles = localArticles.filter { art ->
            art.title.contains(userQuery, ignoreCase = true) ||
            art.summary.contains(userQuery, ignoreCase = true) ||
            art.fullContent.contains(userQuery, ignoreCase = true) ||
            art.category.contains(userQuery, ignoreCase = true)
        }.take(3)

        val matchingHadiths = localHadiths.filter { h ->
            h.title.contains(userQuery, ignoreCase = true) ||
            h.hadithText.contains(userQuery, ignoreCase = true) ||
            h.medicalSignificance.contains(userQuery, ignoreCase = true)
        }.take(2)

        val localContextText = StringBuilder().apply {
            append("--- [بيانات ومعلومات مستخرجة من قاعدة البيانات المحلية Room] ---\n\n")

            if (matchingArticles.isNotEmpty()) {
                append("📚 المقالات الطبية ذات الصلة بالموضوع:\n")
                matchingArticles.forEach { art ->
                    append("• [${art.category}] ${art.title}\n  الملخص: ${art.summary}\n  التفسير الفسيولوجي: ${art.physiologicalMechanism}\n  الإحصائيات: ${art.keyStats}\n\n")
                }
            } else if (localArticles.isNotEmpty()) {
                val sampleArt = localArticles.first()
                append("📚 مقال استرشادي محلي من قاعدة البيانات:\n")
                append("• [${sampleArt.category}] ${sampleArt.title}\n  الملخص: ${sampleArt.summary}\n\n")
            }

            if (matchingHadiths.isNotEmpty()) {
                append("✨ الأحاديث النبوية والإعجاز العلمي المرتبط:\n")
                matchingHadiths.forEach { h ->
                    append("• ${h.title}: \"${h.hadithText}\"\n  التفسير الطبي: ${h.medicalSignificance}\n\n")
                }
            } else if (localHadiths.isNotEmpty()) {
                val sampleHadith = localHadiths.first()
                append("✨ حديث استرشادي محلي من قاعدة البيانات:\n")
                append("• ${sampleHadith.title}: \"${sampleHadith.hadithText}\"\n  التفسير الطبي: ${sampleHadith.medicalSignificance}\n\n")
            }
        }.toString()

        // 2. Build system instruction and augmented user prompt
        val systemInstructionText = """
            أنت استشاري طبي وتأطير فسيولوجي خبير يعمل عبر خدمة Retrofit المرتبطة بموسوعة قاعدة البيانات المحلية Room.
            مهمتك هي تحليل استعلام المستخدم الطبي وتزويده بتفسير فسيولوجي دقيق، مستعيناً بالمعلومات والمقالات والأحاديث المستخرجة من قاعدة البيانات المحلية Room، مع ربط الأدلة الطبية الحديثة بتكامل أجهزة الجسم والحكمة النبوية الشريفة.
        """.trimIndent()

        val fullUserPrompt = """
            استعلام المستخدم الطبي:
            $userQuery

            $localContextText

            يرجى تقديم تفسير فسيولوجي وطبي شامل باللغة العربية الفصحى منظم كالتالي:
            1. التفسير والتعليل الفسيولوجي للاستعلام.
            2. الربط التكاملي مع المقالات والأحاديث المستخرجة من قاعدة البيانات المحلية (Room DB).
            3. التوصيات والإرشادات السريرية للمتابعة.
        """.trimIndent()

        // 3. Construct Retrofit Moshi Request DTO
        val request = GeminiRequest(
            contents = listOf(
                GeminiContent(
                    parts = listOf(GeminiPart(text = fullUserPrompt))
                )
            ),
            systemInstruction = GeminiContent(
                parts = listOf(GeminiPart(text = systemInstructionText))
            )
        )

        // 4. Call Retrofit API Service
        try {
            val response = RetrofitClient.geminiService.generateContent(apiKey, request)
            val candidateText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            candidateText ?: "تم الاتصال بـ Retrofit ولكن لم يتم إرجاع نص تفسير فسيولوجي."
        } catch (e: Exception) {
            "خطأ في خدمة Retrofit عند الاتصال بـ Gemini API: ${e.localizedMessage}"
        }
    }
}
