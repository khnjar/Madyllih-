package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.*
import com.example.api.*
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

sealed class AiResponseState {
    object Idle : AiResponseState()
    object Loading : AiResponseState()
    data class Success(val responseText: String) : AiResponseState()
    data class Error(val message: String) : AiResponseState()
}

class MedicalViewModel(private val repository: MedicalRepository) : ViewModel() {

    private val geminiMedicalService = GeminiMedicalService(repository)

    // UI Tab State
    private val _activeTab = MutableStateFlow("systems")
    val activeTab: StateFlow<String> = _activeTab.asStateFlow()

    // Selected Body System Detail State
    private val _selectedSystem = MutableStateFlow<BodySystem?>(null)
    val selectedSystem: StateFlow<BodySystem?> = _selectedSystem.asStateFlow()

    // Shared Search Query
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // AI Diagnostic Assistant Response State
    private val _aiResponseState = MutableStateFlow<AiResponseState>(AiResponseState.Idle)
    val aiResponseState: StateFlow<AiResponseState> = _aiResponseState.asStateFlow()

    // Room Database Flows
    val savedPrescriptions: StateFlow<List<SavedPrescription>> = repository.allPrescriptions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val calculationLogs: StateFlow<List<CalculationLog>> = repository.allCalculationLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bookmarks: StateFlow<List<BookmarkedTopic>> = repository.allBookmarks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val quizResults: StateFlow<List<QuizResultEntity>> = repository.allQuizResults
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val articles: StateFlow<List<MedicalArticleEntity>> = repository.allArticles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val hadiths: StateFlow<List<HadithEntity>> = repository.allHadiths
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val patientRecords: StateFlow<List<PatientVitalRecordEntity>> = repository.allPatientRecords
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Pre-populate Room DB with initial high-quality medical articles and Prophetic Hadiths if empty
        viewModelScope.launch {
            val currentArticles = repository.allArticles.first()
            if (currentArticles.isEmpty()) {
                repository.insertArticles(MedicalData.defaultArticles)
            }
            val currentHadiths = repository.allHadiths.first()
            if (currentHadiths.isEmpty()) {
                repository.insertHadiths(MedicalData.defaultHadiths)
            }
        }
    }

    fun saveQuizResult(systemId: String, systemTitle: String, score: Int, totalQuestions: Int) {
        viewModelScope.launch {
            val percentage = if (totalQuestions > 0) (score * 100) / totalQuestions else 0
            val feedback = when {
                percentage >= 90 -> "ممتاز جداً! إدراك عميق ومتميز للفسيولوجيا والتكامل الطبي."
                percentage >= 70 -> "جيد جداً! استيعاب قوي ومستقر للأجهزة الحيوية."
                percentage >= 50 -> "جيد، بحاجة لمراجعة تفصيلية إضافية للآليات والتعاليم."
                else -> "تحتاج لمزيد من المراجعة والاطلاع على الشرح العلمي والنبوي المرفق."
            }
            repository.insertQuizResult(
                QuizResultEntity(
                    systemId = systemId,
                    systemTitle = systemTitle,
                    score = score,
                    totalQuestions = totalQuestions,
                    percentage = percentage,
                    feedback = feedback
                )
            )
        }
    }

    fun deleteQuizResult(id: Int) {
        viewModelScope.launch {
            repository.deleteQuizResultById(id)
        }
    }

    // Update States
    fun setTab(tab: String) {
        _activeTab.value = tab
    }

    fun selectSystem(system: BodySystem?) {
        _selectedSystem.value = system
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    // Bookmarks management
    fun toggleBookmark(type: String, topicId: String, topicTitle: String) {
        viewModelScope.launch {
            val isCurrentlyBookmarked = bookmarks.value.any { it.topicType == type && it.topicId == topicId }
            if (isCurrentlyBookmarked) {
                repository.deleteBookmark(type, topicId)
            } else {
                repository.insertBookmark(
                    BookmarkedTopic(
                        topicType = type,
                        topicId = topicId,
                        topicTitle = topicTitle
                    )
                )
            }
        }
    }

    fun isBookmarked(type: String, topicId: String): Flow<Boolean> {
        return repository.isBookmarked(type, topicId)
    }

    // Custom Room Operations for Articles & Hadiths
    fun addMedicalArticle(
        title: String,
        category: String,
        summary: String,
        fullContent: String,
        mechanism: String,
        keyStats: String,
        evidenceLevel: String,
        recommendations: String,
        authorRef: String
    ) {
        viewModelScope.launch {
            val newArticle = MedicalArticleEntity(
                id = "art_custom_${System.currentTimeMillis()}",
                title = title.ifBlank { "مقالة طبية مخصصة" },
                category = category.ifBlank { "عام" },
                summary = summary.ifBlank { "تلخيص المقال السريري" },
                fullContent = fullContent.ifBlank { "محتوى المقال التفصيلي" },
                physiologicalMechanism = mechanism.ifBlank { "التفسير الفسيولوجي" },
                keyStats = keyStats.ifBlank { "معدلات وإحصائيات طردية" },
                evidenceLevel = evidenceLevel.ifBlank { "Level 1A - أدلة سريرية" },
                recommendations = recommendations.ifBlank { "توصيات سريرية وقائية" },
                authorReference = authorRef.ifBlank { "الموسوعة الطبية" }
            )
            repository.insertArticle(newArticle)
        }
    }

    fun deleteArticle(id: String) {
        viewModelScope.launch {
            repository.deleteArticleById(id)
        }
    }

    fun addHadith(
        title: String,
        hadithText: String,
        narrationSource: String,
        narrator: String,
        medicalSignificance: String,
        organConnections: String,
        modernParallel: String
    ) {
        viewModelScope.launch {
            val newHadith = HadithEntity(
                id = "hadith_custom_${System.currentTimeMillis()}",
                title = title.ifBlank { "حديث نبوي شريف" },
                hadithText = hadithText,
                narrationSource = narrationSource.ifBlank { "المصادر المعتمدة" },
                narrator = narrator.ifBlank { "عن أحد الصحابة رضي الله عنهم" },
                medicalSignificance = medicalSignificance.ifBlank { "الشرح والإعجاز العلمي والفسيولوجي" },
                organConnections = organConnections.ifBlank { "أجهزة الجسم الحيوية" },
                modernPhysiologyParallel = modernParallel.ifBlank { "التوافق مع أحدث المنهجيات والبحوث الطبية" }
            )
            repository.insertHadith(newHadith)
        }
    }

    fun deleteHadith(id: String) {
        viewModelScope.launch {
            repository.deleteHadithById(id)
        }
    }

    // Patient Vital Record Management
    fun savePatientRecord(
        patientName: String,
        systolicBp: Int,
        diastolicBp: Int,
        heartRate: Int,
        bloodGlucose: Double,
        oxygenSat: Int,
        temperature: Double,
        riskAssessment: String,
        aiRecommendation: String
    ) {
        viewModelScope.launch {
            val record = PatientVitalRecordEntity(
                patientName = patientName.ifBlank { "مريض مجهول" },
                systolicBp = systolicBp,
                diastolicBp = diastolicBp,
                heartRate = heartRate,
                bloodGlucose = bloodGlucose,
                oxygenSat = oxygenSat,
                temperature = temperature,
                riskAssessment = riskAssessment,
                aiRecommendation = aiRecommendation
            )
            repository.insertPatientRecord(record)
        }
    }

    fun deletePatientRecord(id: Int) {
        viewModelScope.launch {
            repository.deletePatientRecordById(id)
        }
    }

    // Prescription triggers
    fun insertPrescription(condition: String, regimen: String, duration: String, monitoring: String) {
        viewModelScope.launch {
            val prescription = SavedPrescription(
                condition = condition,
                regimen = regimen,
                duration = duration,
                monitoring = monitoring,
                isCustom = true
            )
            repository.insertPrescription(prescription)
        }
    }

    fun deletePrescription(id: Int) {
        viewModelScope.launch {
            repository.deletePrescriptionById(id)
        }
    }

    // Calculation Logs management
    fun insertCalculationLog(patientName: String, modelUsed: String, inputsSummary: String, calculatedResult: String, scoreText: String) {
        viewModelScope.launch {
            val log = CalculationLog(
                patientName = patientName.ifBlank { "مريض مجهول" },
                modelUsed = modelUsed,
                inputsSummary = inputsSummary,
                calculatedResult = calculatedResult,
                scoreText = scoreText
            )
            repository.insertCalculationLog(log)
        }
    }

    fun deleteCalculationLog(id: Int) {
        viewModelScope.launch {
            repository.deleteCalculationLogById(id)
        }
    }

    // Gemini API AI Diagnostic & Prognosis Consultation
    fun consultGeminiDiagnosticAssistant(symptomsText: String, vitalsText: String) {
        viewModelScope.launch(Dispatchers.IO) {
            _aiResponseState.value = AiResponseState.Loading
            try {
                val apiKey = BuildConfig.GEMINI_API_KEY
                val prompt = """
                    أنت استشاري طبي وتأطير فسيولوجي خبير يعمل بداخل الموسوعة الطبية الشاملة والتكامل الفسيولوجي والحديث النبوي الشريف.
                    
                    يرجى تحليل الحالة السريرية التالية بدقة علمية عالية جداً وتقديم تقرير متكامل يتضمن العناصر التالية:
                    1. التشخيص التفريقي الشامل (Differential Diagnosis) مع ذكر نسب الاحتمالية التقديرية لكل مرض.
                    2. الآلية والتعليل الفسيولوجي (Physiological Mechanism) الذي يفسر ظهور هذه الأعراض واختلال العلامات الحيوية.
                    3. الاستشراف والتوقعات المستقبلية (Prognosis & Predictive Risk Analytics) للحالة إذا لم تتلقَ الرعاية المناسبة.
                    4. التوصيات السريرية، الفحوصات المخبرية والطبية المطلوبة فوراً (Urgent Investigations & Management).
                    5. الربط مع التكامل بين أجهزة الجسم والحديث النبوي الشريف المقترن بتداعي الأعضاء أو الوقاية إن وُجد.
                    
                    بيانات شكوى المريض والأعراض:
                    $symptomsText
                    
                    العلامات الحيوية والتحاليل الحالية:
                    ${if (vitalsText.isNotBlank()) vitalsText else "العلامات الحيوية قياسية ضمن الحدود المستقرة"}
                """.trimIndent()

                val client = OkHttpClient.Builder()
                    .connectTimeout(35, java.util.concurrent.TimeUnit.SECONDS)
                    .readTimeout(35, java.util.concurrent.TimeUnit.SECONDS)
                    .build()

                val requestJson = JSONObject().apply {
                    val contentsArray = JSONArray().apply {
                        val contentObj = JSONObject().apply {
                            val partsArray = JSONArray().apply {
                                put(JSONObject().apply { put("text", prompt) })
                            }
                            put("parts", partsArray)
                        }
                        put(contentObj)
                    }
                    put("contents", contentsArray)
                }

                val mediaType = "application/json; charset=utf-8".toMediaType()
                val body = RequestBody.create(mediaType, requestJson.toString())
                val request = Request.Builder()
                    .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey")
                    .post(body)
                    .build()

                val response = client.newCall(request).execute()
                if (response.isSuccessful) {
                    val responseStr = response.body?.string() ?: ""
                    val jsonObj = JSONObject(responseStr)
                    val candidates = jsonObj.optJSONArray("candidates")
                    if (candidates != null && candidates.length() > 0) {
                        val text = candidates.getJSONObject(0)
                            .optJSONObject("content")
                            ?.optJSONArray("parts")
                            ?.optJSONObject(0)
                            ?.optString("text") ?: "تم إكمال التحليل التشخيصي ولكن بدون نصوص إضافية."
                        _aiResponseState.value = AiResponseState.Success(text)
                    } else {
                        _aiResponseState.value = AiResponseState.Error("لم تعُد القناة التشخيصية بالنتيجة المتوقعة.")
                    }
                } else {
                    _aiResponseState.value = AiResponseState.Error("عفواً، يتعذر الاتصال بخدمة التحليل الذكي حالياً (كود الخطأ: ${response.code}). يمكنك الاستعانة بالأدوات المحلية الحالية.")
                }
            } catch (e: Exception) {
                _aiResponseState.value = AiResponseState.Error("تعذر إكمال الاستشارة: ${e.localizedMessage}. يرجى التحقق من الاتصال أومراجعة المعلومات المكتوبة.")
            }
        }
    }

    fun clearAiResponse() {
        _aiResponseState.value = AiResponseState.Idle
    }

    // Retrofit Gemini API Service combined with Room Database
    suspend fun queryRetrofitService(userQuery: String): String {
        return geminiMedicalService.getPhysiologicalInterpretationWithLocalDb(userQuery)
    }

    fun consultGeminiWithRetrofitAndRoom(userQuery: String) {
        viewModelScope.launch(Dispatchers.IO) {
            _aiResponseState.value = AiResponseState.Loading
            try {
                val responseText = geminiMedicalService.getPhysiologicalInterpretationWithLocalDb(userQuery)
                _aiResponseState.value = AiResponseState.Success(responseText)
            } catch (e: Exception) {
                _aiResponseState.value = AiResponseState.Error("خطأ في الخدمة: ${e.localizedMessage}")
            }
        }
    }

    // ==========================================
    // 1. Framingham Point Score Calculator
    // ==========================================
    fun calculateFraminghamRisk(
        age: Int,
        isFemale: Boolean,
        sbp: Int,
        isSbpTreated: Boolean,
        totalCholesterol: Int,
        isSmoker: Boolean,
        isDiabetic: Boolean
    ): Pair<Double, Int> {
        var points = 0

        // 1. Age Points
        if (!isFemale) {
            points += when {
                age in 30..34 -> 0
                age in 35..39 -> 2
                age in 40..44 -> 5
                age in 45..49 -> 7
                age in 50..54 -> 8
                age in 55..59 -> 10
                age in 60..64 -> 11
                age in 65..69 -> 12
                age in 70..74 -> 14
                age >= 75 -> 15
                else -> 0
            }
        } else {
            points += when {
                age in 30..34 -> 0
                age in 35..39 -> 2
                age in 40..44 -> 4
                age in 45..49 -> 5
                age in 50..54 -> 7
                age in 55..59 -> 8
                age in 60..64 -> 9
                age in 65..69 -> 10
                age in 70..74 -> 12
                age >= 75 -> 13
                else -> 0
            }
        }

        // 2. Total Cholesterol Points
        points += when {
            totalCholesterol < 160 -> 0
            totalCholesterol in 160..199 -> 1
            totalCholesterol in 200..239 -> 2
            else -> 3 // >=240
        }

        // 3. Smoking Points
        if (isSmoker) {
            points += if (!isFemale) 4 else 3
        }

        // 4. Systolic Blood Pressure (SBP) Points
        points += when {
            sbp < 120 -> 0
            sbp in 120..129 -> 1
            sbp in 130..139 -> 2
            sbp in 140..159 -> 3
            else -> 4 // >=160
        }
        if (isSbpTreated && sbp >= 120) {
            points += 1
        }

        // 5. Diabetes points
        if (isDiabetic) {
            points += if (!isFemale) 2 else 4
        }

        // Map points to 10-year risk percentage
        val riskPercentage = when {
            points <= 0 -> 1.0
            points in 1..4 -> 2.0
            points in 5..8 -> 4.0
            points in 9..11 -> 6.5
            points in 12..14 -> 11.0
            points in 15..16 -> 18.5
            points >= 17 -> 32.0
            else -> 35.0
        }

        return Pair(riskPercentage, points)
    }

    // ==========================================
    // 2. CHA₂DS₂-VASc Stroke Risk Calculator
    // ==========================================
    fun calculateCha2ds2Vasc(
        hasChf: Boolean,
        hasHypertension: Boolean,
        age: Int,
        hasDiabetes: Boolean,
        hasStroke: Boolean,
        hasVascular: Boolean,
        isFemale: Boolean
    ): Pair<Double, Int> {
        var score = 0
        if (hasChf) score += 1
        if (hasHypertension) score += 1
        if (age >= 75) score += 2 else if (age in 65..74) score += 1
        if (hasDiabetes) score += 1
        if (hasStroke) score += 2
        if (hasVascular) score += 1
        if (isFemale) score += 1

        val riskPercent = when (score) {
            0 -> 0.0
            1 -> 1.3
            2 -> 2.2
            3 -> 3.2
            4 -> 4.0
            5 -> 6.7
            6 -> 9.8
            7 -> 11.2
            8 -> 12.5
            else -> 15.0 // 9
        }

        return Pair(riskPercent, score)
    }

    // ==========================================
    // 3. eGFR CKD-EPI (2021 Race-Free Equation)
    // ==========================================
    fun calculateCkdEpiEGfr(
        creatinine: Double,
        age: Int,
        isFemale: Boolean
    ): Pair<Double, String> {
        if (creatinine <= 0.0) return Pair(0.0, "خطأ في عيار الكرياتينين")

        val kappa = if (isFemale) 0.7 else 0.9
        val alpha = if (isFemale) -0.241 else -0.302
        val genderCoeff = if (isFemale) 1.012 else 1.0

        val crRatio = creatinine / kappa
        val minRatio = min(crRatio, 1.0)
        val maxRatio = max(crRatio, 1.0)

        val egfrVal = 142.0 *
                minRatio.pow(alpha) *
                maxRatio.pow(-1.200) *
                0.9938.pow(age.toDouble()) *
                genderCoeff

        val roundedEgfr = (egfrVal * 10).toInt() / 10.0

        val stage = when {
            roundedEgfr >= 90.0 -> "المرحلة الأولى G1 (تنظيم طبيعي أو عالي: وظائف كلوية سليمة)"
            roundedEgfr >= 60.0 -> "المرحلة الثانية G2 (انخفاض طفيف: رصد ومتابعة كلوية)"
            roundedEgfr >= 45.0 -> "المرحلة الثالثة أ G3a (انخفاض طفيف إلى متوسط: رصد وعناية كلوية)"
            roundedEgfr >= 30.0 -> "المرحلة الثالثة ب G3b (انخفاض متوسط إلى شديد: معالجة وقائية مشددة)"
            roundedEgfr >= 15.0 -> "المرحلة الرابعة G4 (انخفاض شديد: تجهيز مسبق لغسيل/ديلزة الكلى)"
            else -> "المرحلة الخامسة G5 (فشل كلوي نهائي: ديلزة أو زرع كلى مستعجل)"
        }

        return Pair(roundedEgfr, stage)
    }

    fun calculateBmi(weightKg: Double, heightCm: Double): Pair<Double, String> {
        if (weightKg <= 0.0 || heightCm <= 0.0) return Pair(0.0, "يرجى إدخال قيم صحيحة")
        
        val heightM = heightCm / 100.0
        val bmiVal = weightKg / (heightM * heightM)
        val roundedBmi = (bmiVal * 10).toInt() / 10.0
        
        val category = when {
            roundedBmi < 18.5 -> "نقص في الوزن (Underweight)"
            roundedBmi < 25.0 -> "وزن طبيعي صحي (Normal weight)"
            roundedBmi < 30.0 -> "زيادة في الوزن (Overweight)"
            roundedBmi < 35.0 -> "سمنة من الدرجة الأولى (Obesity Class I)"
            roundedBmi < 40.0 -> "سمنة من الدرجة الثانية (Obesity Class II)"
            else -> "سمنة مفرطة من الدرجة الثالثة (Obesity Class III)"
        }
        
        return Pair(roundedBmi, category)
    }

    // ==========================================
    // 4. Mean Arterial Pressure (MAP) & Pulse Pressure
    // ==========================================
    fun calculateMap(sbp: Int, dbp: Int): Triple<Double, Int, String> {
        val pulsePressure = sbp - dbp
        val map = dbp + (pulsePressure / 3.0)
        val roundedMap = (map * 10).toInt() / 10.0

        val status = when {
            roundedMap < 65.0 -> "هبوط تروية حرج للأعضاء الحيوية (خطر نقص أكسجة الدماغ والكلى)"
            roundedMap in 65.0..100.0 -> "ضغط تروية شرياني طبيعي ومثالي للأعضاء (65 - 100 mmHg)"
            roundedMap in 100.1..110.0 -> "ضغط شرياني متوسط مرتفع نسبياً (يحتاج متابعة دورية)"
            else -> "فرط ضغط شرياني حاد (عبء مرتفع على القلب والشرايين الدماغية)"
        }

        return Triple(roundedMap, pulsePressure, status)
    }

    // ==========================================
    // 5. Body Surface Area (BSA) - Mosteller Formula
    // ==========================================
    fun calculateBsa(weightKg: Double, heightCm: Double): Double {
        if (weightKg <= 0.0 || heightCm <= 0.0) return 0.0
        val bsa = kotlin.math.sqrt((weightKg * heightCm) / 3600.0)
        return (bsa * 100).toInt() / 100.0
    }

    // ==========================================
    // 6. Basal Metabolic Rate (BMR) - Mifflin-St Jeor & Harris-Benedict
    // ==========================================
    fun calculateBmr(
        weightKg: Double,
        heightCm: Double,
        age: Int,
        isFemale: Boolean
    ): Pair<Double, Double> {
        if (weightKg <= 0.0 || heightCm <= 0.0 || age <= 0) return Pair(0.0, 0.0)

        // Mifflin-St Jeor
        val mifflin = (10.0 * weightKg) + (6.25 * heightCm) - (5.0 * age) + if (isFemale) -161.0 else 5.0
        // Harris-Benedict (Revised)
        val harris = if (isFemale) {
            447.593 + (9.247 * weightKg) + (3.098 * heightCm) - (4.330 * age)
        } else {
            88.362 + (13.397 * weightKg) + (4.799 * heightCm) - (5.677 * age)
        }

        val roundedMifflin = (mifflin * 10).toInt() / 10.0
        val roundedHarris = (harris * 10).toInt() / 10.0
        return Pair(roundedMifflin, roundedHarris)
    }

    // ==========================================
    // 7. Ideal Body Weight (Devine Formula)
    // ==========================================
    fun calculateIdealWeight(heightCm: Double, isFemale: Boolean): Double {
        if (heightCm <= 100.0) return 0.0
        val heightInches = heightCm / 2.54
        val inchesOver5Feet = max(0.0, heightInches - 60.0)
        val baseWeight = if (isFemale) 45.5 else 50.0
        val ibw = baseWeight + (2.3 * inchesOver5Feet)
        return (ibw * 10).toInt() / 10.0
    }
}

class MedicalViewModelFactory(private val repository: MedicalRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MedicalViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MedicalViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
