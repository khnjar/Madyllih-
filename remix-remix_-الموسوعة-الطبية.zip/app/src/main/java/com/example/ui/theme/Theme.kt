package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

import androidx.compose.ui.graphics.Color

private val DarkColorScheme =
  darkColorScheme(
    primary = Color(0xFF38BDF8),       // Sky 400
    secondary = Color(0xFFC084FC),     // Violet 400
    tertiary = Color(0xFFF1F5F9),      // Slate 100
    background = Color(0xFF050810),    // Deep clinical base
    surface = Color(0xFF0F172A),       // Slate 900
    onPrimary = Color(0xFF020617),
    onSecondary = Color(0xFF020617),
    onBackground = Color(0xFFF1F5F9),
    onSurface = Color(0xFFF1F5F9)
  )

private val LightColorScheme = DarkColorScheme // Forced dark theme for absolute clinic immersion

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Force dark theme
  dynamicColor: Boolean = false, // Use our gorgeous custom dark theme
  content: @Composable () -> Unit,
) {
  val colorScheme = DarkColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
