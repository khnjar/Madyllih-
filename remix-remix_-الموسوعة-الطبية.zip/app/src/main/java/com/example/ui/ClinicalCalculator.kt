package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlin.math.cos
import kotlin.math.sin

/**
 * Clinical Calculator Suite (الحاسبة السريرية والفسيولوجية المتكاملة)
 * Supports BMI, BSA, eGFR (CKD-EPI 2021), MAP & Pulse Pressure, BMR, and Cardiovascular Risk.
 * Fully follows Arabic RTL guidelines, Material 3 theming, and Room DB logging.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ClinicalCalculatorScreen(
    viewModel: MedicalViewModel,
    modifier: Modifier = Modifier
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        val haptic = LocalHapticFeedback.current
        val clipboardManager = LocalClipboardManager.current
        val calculationLogs by viewModel.calculationLogs.collectAsStateWithLifecycle()

        var selectedCalculatorIndex by remember { mutableIntStateOf(0) }
        var toastMessage by remember { mutableStateOf<String?>(null) }

        // Common Patient Inputs
        var patientName by remember { mutableStateOf("مريض بدون اسم") }
        var isFemale by remember { mutableStateOf(false) }
        var ageText by remember { mutableStateOf("45") }
        var weightText by remember { mutableStateOf("75.0") }
        var heightText by remember { mutableStateOf("172.0") }

        // Cardiovascular & Renal Specific Inputs
        var sbpText by remember { mutableStateOf("130") }
        var dbpText by remember { mutableStateOf("85") }
        var creatinineText by remember { mutableStateOf("1.0") }
        var totalCholText by remember { mutableStateOf("190") }
        var isSmoker by remember { mutableStateOf(false) }
        var isDiabetic by remember { mutableStateOf(false) }
        var isSbpTreated by remember { mutableStateOf(false) }

        // Toast Notification Timer
        LaunchedEffect(toastMessage) {
            if (toastMessage != null) {
                kotlinx.coroutines.delay(2600)
                toastMessage = null
            }
        }

        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .background(Color(0xFF050810))
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Card
            item {
                Card(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A).copy(alpha = 0.95f)),
                    border = BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = Color(0xFF38BDF8).copy(alpha = 0.15f),
                                    border = BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.3f))
                                ) {
                                    Text(
                                        text = "🧮",
                                        fontSize = 24.sp,
                                        modifier = Modifier.padding(6.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "الحاسبة السريرية والفسيولوجية",
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color.White,
                                        fontSize = 16.sp
                                    )
                                    Text(
                                        text = "معادلات معتمدة دولياً (WHO, KDIGO, AHA) مع حفظ محلي",
                                        color = Color(0xFF38BDF8),
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFF1E293B),
                                border = BorderStroke(1.dp, Color(0xFF10B981))
                            ) {
                                Text(
                                    text = "Room SQLite ⚡",
                                    color = Color(0xFF10B981),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Text(
                            text = "احسب بدقة مؤشرات كتلة الجسم، معدل الترشيح الكلوي، ضغط التروية الشرياني، ومعدل الأيض اليومي مع التفسير العلمي وحفظ السجلات.",
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp,
                            lineHeight = 16.sp
                        )
                    }
                }
            }

            // Toast Alert
            item {
                AnimatedVisibility(visible = toastMessage != null) {
                    Surface(
                        color = Color(0xFF10B981),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = toastMessage ?: "",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            }

            // Quick Clinical Presets Row
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "⚡ حالات سريرية جاهزة للاختبار الفوري:",
                        color = Color(0xFFCBD5E1),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        val presets = listOf(
                            Triple("بالغ سليم (رياضي)", "شاب رياضي صحي", Pair(25, Pair(72.0, 178.0))),
                            Triple("مريض ضغط وسكري", "حالة مخاطر أيضية", Pair(56, Pair(88.0, 168.0))),
                            Triple("مسن اعتلال كلوي", "مريض قصور وظائف", Pair(74, Pair(63.0, 162.0))),
                            Triple("سيدة زيادة وزن", "متابعة حمية وأيض", Pair(38, Pair(82.0, 160.0)))
                        )
                        items(presets) { (title, name, params) ->
                            SuggestionChip(
                                onClick = {
                                    patientName = name
                                    ageText = params.first.toString()
                                    weightText = params.second.first.toString()
                                    heightText = params.second.second.toString()
                                    if (title.contains("سيدة")) {
                                        isFemale = true
                                        creatinineText = "0.9"
                                    } else if (title.contains("اعتلال")) {
                                        isFemale = false
                                        creatinineText = "2.1"
                                        sbpText = "148"
                                        dbpText = "92"
                                    } else if (title.contains("ضغط")) {
                                        isFemale = false
                                        isDiabetic = true
                                        isSmoker = true
                                        sbpText = "152"
                                        dbpText = "94"
                                        creatinineText = "1.3"
                                    } else {
                                        isFemale = false
                                        isDiabetic = false
                                        isSmoker = false
                                        sbpText = "118"
                                        dbpText = "76"
                                        creatinineText = "0.9"
                                    }
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                },
                                label = {
                                    Text(title, fontSize = 11.sp, color = Color(0xFF38BDF8), fontWeight = FontWeight.Medium)
                                },
                                colors = SuggestionChipDefaults.suggestionChipColors(containerColor = Color(0xFF1E293B)),
                                border = BorderStroke(1.dp, Color(0xFF334155))
                            )
                        }
                    }
                }
            }

            // Metric Tabs Selector
            item {
                val metricTabs = listOf(
                    0 to "⚖️ الكتلة والسطح (BMI & BSA)",
                    1 to "🫘 الترشيح الكلوي (eGFR)",
                    2 to "🫀 التروية والضغط (MAP)",
                    3 to "⚡ معدل الأيض (BMR)",
                    4 to "📊 مخاطر القلب (CVD)"
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(metricTabs) { (index, label) ->
                        val isSelected = selectedCalculatorIndex == index
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                selectedCalculatorIndex = index
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            },
                            label = {
                                Text(
                                    text = label,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color.White else Color(0xFF94A3B8)
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFF0284C7),
                                containerColor = Color(0xFF0F172A)
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = if (isSelected) Color(0xFF38BDF8) else Color(0xFF334155)
                            )
                        )
                    }
                }
            }

            // Shared Demographics Panel
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A).copy(alpha = 0.7f)),
                    border = BorderStroke(1.dp, Color(0xFF334155).copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "👤 البيانات الحيوية للمريض:",
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF38BDF8),
                                fontSize = 12.sp
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("أنثى", fontSize = 11.sp, color = if (isFemale) Color(0xFFEC4899) else Color(0xFF64748B))
                                Switch(
                                    checked = isFemale,
                                    onCheckedChange = { isFemale = it },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color(0xFFEC4899),
                                        checkedTrackColor = Color(0xFF831843)
                                    )
                                )
                                Text("ذكر", fontSize = 11.sp, color = if (!isFemale) Color(0xFF38BDF8) else Color(0xFF64748B))
                            }
                        }

                        OutlinedTextField(
                            value = patientName,
                            onValueChange = { patientName = it },
                            label = { Text("معرف أو اسم المريض") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF38BDF8),
                                unfocusedBorderColor = Color(0xFF334155),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = ageText,
                                onValueChange = { ageText = it },
                                label = { Text("العمر (سنة)") },
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color(0xFF38BDF8),
                                    unfocusedBorderColor = Color(0xFF334155),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                )
                            )
                            OutlinedTextField(
                                value = weightText,
                                onValueChange = { weightText = it },
                                label = { Text("الوزن (kg)") },
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color(0xFF38BDF8),
                                    unfocusedBorderColor = Color(0xFF334155),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                )
                            )
                            OutlinedTextField(
                                value = heightText,
                                onValueChange = { heightText = it },
                                label = { Text("الطول (cm)") },
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color(0xFF38BDF8),
                                    unfocusedBorderColor = Color(0xFF334155),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                )
                            )
                        }
                    }
                }
            }

            // Metric View Selector Rendering
            item {
                val weight = weightText.toDoubleOrNull() ?: 70.0
                val height = heightText.toDoubleOrNull() ?: 170.0
                val age = ageText.toIntOrNull() ?: 45
                val sbp = sbpText.toIntOrNull() ?: 120
                val dbp = dbpText.toIntOrNull() ?: 80
                val creatinine = creatinineText.toDoubleOrNull() ?: 1.0

                when (selectedCalculatorIndex) {
                    0 -> {
                        // 1. BMI & BSA View
                        val (bmi, bmiCategory) = viewModel.calculateBmi(weight, height)
                        val bsa = viewModel.calculateBsa(weight, height)
                        val idealWeight = viewModel.calculateIdealWeight(height, isFemale)

                        BmiBsaResultCard(
                            bmi = bmi,
                            bmiCategory = bmiCategory,
                            bsa = bsa,
                            idealWeight = idealWeight,
                            onSave = {
                                viewModel.insertCalculationLog(
                                    patientName = patientName,
                                    modelUsed = "BMI & BSA",
                                    inputsSummary = "${if (isFemale) "أنثى" else "ذكر"}، $age سنة، $weight kg، $height cm",
                                    calculatedResult = "$bmi kg/m² ($bmiCategory) | BSA: $bsa m²",
                                    scoreText = "$bmi"
                                )
                                toastMessage = "✓ تم حفظ حساب مؤشر كتلة الجسم ومساحة السطح في سجلات Room DB"
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            },
                            onCopy = {
                                val report = """
                                    [تقرير سريري - مؤشر كتلة الجسم ومساحة السطح]
                                    المريض: $patientName
                                    الجنس: ${if (isFemale) "أنثى" else "ذكر"} | العمر: $age سنة
                                    الوزن: $weight kg | الطول: $height cm
                                    مؤشر كتلة الجسم (BMI): $bmi kg/m² ($bmiCategory)
                                    مساحة سطح الجسم (BSA): $bsa m²
                                    الوزن المثالي التقديري (Devine): $idealWeight kg
                                    المرجع: منظمة الصحة العالمية (WHO) ومعادلة Mosteller
                                """.trimIndent()
                                clipboardManager.setText(AnnotatedString(report))
                                toastMessage = "✓ تم نسخ التقرير السريري إلى الحافظة"
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            }
                        )
                    }
                    1 -> {
                        // 2. eGFR (CKD-EPI 2021) View
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A).copy(alpha = 0.7f)),
                                border = BorderStroke(1.dp, Color(0xFF334155)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text("معايير وظائف الكلى المخبرية:", fontWeight = FontWeight.Bold, color = Color(0xFF10B981), fontSize = 12.sp)
                                    Spacer(modifier = Modifier.height(8.dp))
                                    OutlinedTextField(
                                        value = creatinineText,
                                        onValueChange = { creatinineText = it },
                                        label = { Text("الكرياتينين في مصل الدم Serum Creatinine (mg/dL)") },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = Color(0xFF10B981),
                                            unfocusedBorderColor = Color(0xFF334155),
                                            focusedTextColor = Color.White,
                                            unfocusedTextColor = Color.White
                                        )
                                    )
                                }
                            }

                            val (egfr, egfrStage) = viewModel.calculateCkdEpiEGfr(creatinine, age, isFemale)

                            EgfrResultCard(
                                egfr = egfr,
                                stage = egfrStage,
                                creatinine = creatinine,
                                onSave = {
                                    viewModel.insertCalculationLog(
                                        patientName = patientName,
                                        modelUsed = "eGFR (CKD-EPI 2021)",
                                        inputsSummary = "${if (isFemale) "أنثى" else "ذكر"}، $age سنة، Cr: $creatinine mg/dL",
                                        calculatedResult = "$egfr mL/min/1.73m² - $egfrStage",
                                        scoreText = "$egfr"
                                    )
                                    toastMessage = "✓ تم حفظ حساب وظائف الكلى eGFR في قاعدة البيانات Room"
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                },
                                onCopy = {
                                    val report = """
                                        [تقرير فسيولوجي - معدل الترشيح الكبيبي الكلوي eGFR]
                                        المريض: $patientName
                                        العمر: $age سنة | الجنس: ${if (isFemale) "أنثى" else "ذكر"}
                                        كرياتينين المصل: $creatinine mg/dL
                                        معدل eGFR المحسوب: $egfr mL/min/1.73m²
                                        المرحلة والتقييم: $egfrStage
                                        المعادلة: CKD-EPI 2021 Race-Free Equation المعتمدة عالمياً
                                    """.trimIndent()
                                    clipboardManager.setText(AnnotatedString(report))
                                    toastMessage = "✓ تم نسخ التقرير الكلوي إلى الحافظة"
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                }
                            )
                        }
                    }
                    2 -> {
                        // 3. MAP & Pulse Pressure View
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A).copy(alpha = 0.7f)),
                                border = BorderStroke(1.dp, Color(0xFF334155)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("قراءات ضغط الدم الشرياني الآنية:", fontWeight = FontWeight.Bold, color = Color(0xFFE11D48), fontSize = 12.sp)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedTextField(
                                            value = sbpText,
                                            onValueChange = { sbpText = it },
                                            label = { Text("الانقباضي SBP (mmHg)") },
                                            singleLine = true,
                                            modifier = Modifier.weight(1f)
                                        )
                                        OutlinedTextField(
                                            value = dbpText,
                                            onValueChange = { dbpText = it },
                                            label = { Text("الانبساطي DBP (mmHg)") },
                                            singleLine = true,
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            }

                            val (mapVal, ppVal, mapStatus) = viewModel.calculateMap(sbp, dbp)

                            MapResultCard(
                                mapValue = mapVal,
                                pulsePressure = ppVal,
                                status = mapStatus,
                                sbp = sbp,
                                dbp = dbp,
                                onSave = {
                                    viewModel.insertCalculationLog(
                                        patientName = patientName,
                                        modelUsed = "MAP & Pulse Pressure",
                                        inputsSummary = "SBP: $sbp, DBP: $dbp mmHg",
                                        calculatedResult = "MAP: $mapVal mmHg ($mapStatus) | ضغط النبض: $ppVal",
                                        scoreText = "$mapVal"
                                    )
                                    toastMessage = "✓ تم حفظ حساب ضغط التروية الشرياني في Room DB"
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                },
                                onCopy = {
                                    val report = """
                                        [تقرير سريري - الضغط الشرياني الوسطي ومؤشر التروية MAP]
                                        المريض: $patientName
                                        ضغط الدم: $sbp/$dbp mmHg
                                        الضغط الشرياني الوسطي (MAP): $mapVal mmHg
                                        ضغط النبض (Pulse Pressure): $ppVal mmHg
                                        التقييم الفسيولوجي: $mapStatus
                                        الأهمية السريرية: الحد الأدنى المطلوب لتروية الكلى والدماغ هو 65 mmHg.
                                    """.trimIndent()
                                    clipboardManager.setText(AnnotatedString(report))
                                    toastMessage = "✓ تم نسخ تقرير ضغط التروية إلى الحافظة"
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                }
                            )
                        }
                    }
                    3 -> {
                        // 4. BMR View
                        val (mifflin, harris) = viewModel.calculateBmr(weight, height, age, isFemale)
                        BmrResultCard(
                            mifflinBmr = mifflin,
                            harrisBmr = harris,
                            weight = weight,
                            onSave = {
                                viewModel.insertCalculationLog(
                                    patientName = patientName,
                                    modelUsed = "BMR (Mifflin & Harris)",
                                    inputsSummary = "${if (isFemale) "أنثى" else "ذكر"}، $age سنة، $weight kg، $height cm",
                                    calculatedResult = "BMR: $mifflin سعرة حرارية/يوم",
                                    scoreText = "$mifflin"
                                )
                                toastMessage = "✓ تم حفظ معدل الأيض الأساسي في قاعدة البيانات"
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            },
                            onCopy = {
                                val report = """
                                    [تقرير الأيض والسعرات الحرارية اليومية BMR]
                                    المريض: $patientName
                                    الجنس: ${if (isFemale) "أنثى" else "ذكر"} | العمر: $age سنة
                                    الوزن: $weight kg | الطول: $height cm
                                    معدل الأيض الأساسي (معادلة Mifflin-St Jeor): $mifflin kcal/day
                                    معدل الأيض (معادلة Harris-Benedict): $harris kcal/day
                                    احتياج الطاقة بحسب النشاط:
                                    - خامل: ${(mifflin * 1.2).toInt()} kcal
                                    - نشاط معتدل: ${(mifflin * 1.55).toInt()} kcal
                                    - نشاط عالي: ${(mifflin * 1.725).toInt()} kcal
                                """.trimIndent()
                                clipboardManager.setText(AnnotatedString(report))
                                toastMessage = "✓ تم نسخ تقرير الأيض الغذائي"
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            }
                        )
                    }
                    4 -> {
                        // 5. CVD Risk (Framingham) View
                        val totalChol = totalCholText.toIntOrNull() ?: 190
                        val (cvdRisk, points) = viewModel.calculateFraminghamRisk(
                            age = age,
                            isFemale = isFemale,
                            sbp = sbp,
                            isSbpTreated = isSbpTreated,
                            totalCholesterol = totalChol,
                            isSmoker = isSmoker,
                            isDiabetic = isDiabetic
                        )

                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A).copy(alpha = 0.7f)),
                            border = BorderStroke(1.dp, Color(0xFF334155)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("عوامل الخطورة القلبية المساعدة:", fontWeight = FontWeight.Bold, color = Color(0xFFF59E0B), fontSize = 12.sp)
                                OutlinedTextField(
                                    value = totalCholText,
                                    onValueChange = { totalCholText = it },
                                    label = { Text("الكوليسترول الكلي Total Cholesterol (mg/dL)") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Text("هل يدخن السجائر حالياً؟", color = Color.White, fontSize = 11.sp)
                                    Checkbox(checked = isSmoker, onCheckedChange = { isSmoker = it })
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Text("هل يعاني من داء السكري؟", color = Color.White, fontSize = 11.sp)
                                    Checkbox(checked = isDiabetic, onCheckedChange = { isDiabetic = it })
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Text("هل يتلقى علاجاً لضغط الدم؟", color = Color.White, fontSize = 11.sp)
                                    Checkbox(checked = isSbpTreated, onCheckedChange = { isSbpTreated = it })
                                }
                            }
                        }

                        CvdRiskResultCard(
                            riskPercent = cvdRisk,
                            points = points,
                            onSave = {
                                viewModel.insertCalculationLog(
                                    patientName = patientName,
                                    modelUsed = "Framingham CVD Risk",
                                    inputsSummary = "$age سنة، SBP: $sbp، مدخن: $isSmoker، سكري: $isDiabetic",
                                    calculatedResult = "$cvdRisk% احتمالية الإصابة خلال 10 سنوات",
                                    scoreText = "$points نقاط"
                                )
                                toastMessage = "✓ تم حفظ مؤشر مخاطر القلب في Room DB"
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            },
                            onCopy = {
                                val report = """
                                    [تقرير سريري - مؤشر Framingham لمخاطر أمراض القلب 10 سنوات]
                                    المريض: $patientName | العمر: $age سنة | الجنس: ${if (isFemale) "أنثى" else "ذكر"}
                                    ضغط الدم: $sbp mmHg | الكوليسترول: $totalChol mg/dL
                                    التدخين: ${if (isSmoker) "نعم" else "لا"} | السكري: ${if (isDiabetic) "نعم" else "لا"}
                                    مجموع النقاط: $points نقطة
                                    احتمالية الإصابة بحدث قلبي وعائي خلال 10 سنوات: $cvdRisk%
                                    المرجع: American Heart Association / Framingham Heart Study
                                """.trimIndent()
                                clipboardManager.setText(AnnotatedString(report))
                                toastMessage = "✓ تم نسخ تقرير المخاطر القلبية"
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            }
                        )
                    }
                }
            }

            // Calculation Logs History Card (Room DB Integration)
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A).copy(alpha = 0.9f)),
                    border = BorderStroke(1.dp, Color(0xFF334155).copy(alpha = 0.6f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("📋", fontSize = 18.sp, modifier = Modifier.padding(end = 6.dp))
                                Text(
                                    text = "سجل الحسابات السريرية المحفوظة محلياً (${calculationLogs.size})",
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 13.sp
                                )
                            }
                        }

                        if (calculationLogs.isEmpty()) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color(0xFF1E293B).copy(alpha = 0.5f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "لم يتم حفظ أي حسابات بعد. اضغط على 'حفظ النتيجة في سجلات Room DB' بالأعلى لحفظ نتائج المرضى وتتبعها.",
                                    color = Color(0xFF94A3B8),
                                    fontSize = 11.sp,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(14.dp)
                                )
                            }
                        } else {
                            calculationLogs.take(5).forEach { log ->
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = Color(0xFF1E293B).copy(alpha = 0.6f),
                                    border = BorderStroke(1.dp, Color(0xFF334155).copy(alpha = 0.4f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Surface(
                                                    shape = RoundedCornerShape(6.dp),
                                                    color = Color(0xFF38BDF8).copy(alpha = 0.15f)
                                                ) {
                                                    Text(
                                                        text = log.modelUsed,
                                                        color = Color(0xFF38BDF8),
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(log.patientName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(log.calculatedResult, color = Color(0xFF10B981), fontSize = 11.sp, fontWeight = FontWeight.Medium)
                                            Text(log.inputsSummary, color = Color(0xFF94A3B8), fontSize = 9.sp)
                                        }

                                        IconButton(
                                            onClick = {
                                                viewModel.deleteCalculationLog(log.id)
                                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                            },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "حذف السجل",
                                                tint = Color(0xFFEF4444),
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// Subcomponent 1: BMI & BSA Result Card
// ==========================================
@Composable
fun BmiBsaResultCard(
    bmi: Double,
    bmiCategory: String,
    bsa: Double,
    idealWeight: Double,
    onSave: () -> Unit,
    onCopy: () -> Unit
) {
    val categoryColor = when {
        bmi < 18.5 -> Color(0xFF38BDF8) // Underweight: Sky Blue
        bmi < 25.0 -> Color(0xFF10B981) // Normal: Emerald
        bmi < 30.0 -> Color(0xFFF59E0B) // Overweight: Amber
        else -> Color(0xFFE11D48)       // Obese: Crimson
    }

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A).copy(alpha = 0.95f)),
        border = BorderStroke(1.dp, categoryColor.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "النتيجة: $bmi kg/m²",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 22.sp,
                        color = categoryColor
                    )
                    Text(
                        text = "التصنيف: $bmiCategory",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }

                // Semicircular Canvas Gauge Meter
                ClinicalGaugeMeter(
                    fraction = (bmi / 45.0).toFloat().coerceIn(0f, 1f),
                    needleColor = categoryColor,
                    label = "$bmi"
                )
            }

            // High-Precision Linear Gradient Risk Gauge with Thresholds
            BmiRiskLinearGauge(bmi = bmi)

            HorizontalDivider(color = Color(0xFF334155))

            // Secondary Metrics
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF1E293B),
                    modifier = Modifier.weight(1f).padding(end = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("مساحة سطح الجسم (BSA)", color = Color(0xFF94A3B8), fontSize = 10.sp)
                        Text("$bsa m²", fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8), fontSize = 14.sp)
                    }
                }
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF1E293B),
                    modifier = Modifier.weight(1f).padding(start = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("الوزن المثالي (Devine)", color = Color(0xFF94A3B8), fontSize = 10.sp)
                        Text("$idealWeight kg", fontWeight = FontWeight.Bold, color = Color(0xFF10B981), fontSize = 14.sp)
                    }
                }
            }

            // Clinical Explanation
            Text(
                text = "💡 التفسير الفسيولوجي: يُعد مؤشر كتلة الجسم المعيار الأساسي لتقييم عبء الدهون والأنسجة على عمل عضلة القلب والشرايين، بينما تفيد مساحة سطح الجسم (BSA) في حساب الجرعات الدوائية الكيميائية بدقة.",
                color = Color(0xFFCBD5E1),
                fontSize = 11.sp,
                lineHeight = 16.sp
            )

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onSave,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981), contentColor = Color.Black),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Save, contentDescription = "", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("حفظ في Room DB", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = onCopy,
                    border = BorderStroke(1.dp, Color(0xFF38BDF8)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Share, contentDescription = "", tint = Color(0xFF38BDF8), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("نسخ التقرير", color = Color(0xFF38BDF8), fontSize = 11.sp)
                }
            }
        }
    }
}

// ==========================================
// Subcomponent 2: eGFR Result Card
// ==========================================
@Composable
fun EgfrResultCard(
    egfr: Double,
    stage: String,
    creatinine: Double,
    onSave: () -> Unit,
    onCopy: () -> Unit
) {
    val stageColor = when {
        egfr >= 90.0 -> Color(0xFF10B981) // Normal / G1
        egfr >= 60.0 -> Color(0xFF38BDF8) // Mild / G2
        egfr >= 30.0 -> Color(0xFFF59E0B) // Moderate / G3
        else -> Color(0xFFE11D48)         // Severe / G4-G5
    }

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A).copy(alpha = 0.95f)),
        border = BorderStroke(1.dp, stageColor.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "eGFR: $egfr",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 22.sp,
                        color = stageColor
                    )
                    Text(
                        text = "mL/min/1.73m² (ترشيح كبيبي)",
                        color = Color(0xFF94A3B8),
                        fontSize = 11.sp
                    )
                }

                ClinicalGaugeMeter(
                    fraction = (egfr / 120.0).toFloat().coerceIn(0f, 1f),
                    needleColor = stageColor,
                    label = "$egfr"
                )
            }

            // High-Precision Linear Gradient Risk Gauge with Thresholds
            EgfrRiskLinearGauge(egfr = egfr)

            Surface(
                shape = RoundedCornerShape(10.dp),
                color = stageColor.copy(alpha = 0.15f),
                border = BorderStroke(1.dp, stageColor.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = stage,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(10.dp)
                )
            }

            Text(
                text = "📌 إرشادات KDIGO: تم حساب القيمة بمعادلة 2021 CKD-EPI الحديثة المحررة من العرق. في المراحل G3 فما فوق، يجب تعديل جرعات المضادات الحيوية ومدرات البول، وتجنب المسكنات اللاستيرويدية (NSAIDs) لحماية النفرونات المتبقية.",
                color = Color(0xFFCBD5E1),
                fontSize = 11.sp,
                lineHeight = 16.sp
            )

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onSave,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981), contentColor = Color.Black),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Save, contentDescription = "", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("حفظ في Room DB", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = onCopy,
                    border = BorderStroke(1.dp, Color(0xFF38BDF8)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Share, contentDescription = "", tint = Color(0xFF38BDF8), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("نسخ التقرير", color = Color(0xFF38BDF8), fontSize = 11.sp)
                }
            }
        }
    }
}

// ==========================================
// Subcomponent 3: MAP Result Card
// ==========================================
@Composable
fun MapResultCard(
    mapValue: Double,
    pulsePressure: Int,
    status: String,
    sbp: Int,
    dbp: Int,
    onSave: () -> Unit,
    onCopy: () -> Unit
) {
    val mapColor = when {
        mapValue < 65.0 -> Color(0xFFE11D48)
        mapValue in 65.0..100.0 -> Color(0xFF10B981)
        else -> Color(0xFFF59E0B)
    }

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A).copy(alpha = 0.95f)),
        border = BorderStroke(1.dp, mapColor.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "MAP: $mapValue mmHg",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 22.sp,
                        color = mapColor
                    )
                    Text(
                        text = "ضغط النبض (Pulse Pressure): $pulsePressure mmHg",
                        color = Color(0xFFCBD5E1),
                        fontSize = 11.sp
                    )
                }

                ClinicalGaugeMeter(
                    fraction = (mapValue / 130.0).toFloat().coerceIn(0f, 1f),
                    needleColor = mapColor,
                    label = "$mapValue"
                )
            }

            // High-Precision Linear Gradient Risk Gauge with Thresholds
            MapRiskLinearGauge(mapValue = mapValue)

            Surface(
                shape = RoundedCornerShape(10.dp),
                color = mapColor.copy(alpha = 0.15f),
                border = BorderStroke(1.dp, mapColor.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = status,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(10.dp)
                )
            }

            Text(
                text = "🫀 التروية العضوية الفسيولوجية: يمثل الضغط الوسطي (MAP) المحرك الأساسي لتدفق الدم عبر الشعيرات إلى الدماغ والكلية والقلب. يعتبر الحفاظ على MAP ≥ 65 mmHg الهدف الذهبي في غرف الإنعاش والعناية الفائقة.",
                color = Color(0xFFCBD5E1),
                fontSize = 11.sp,
                lineHeight = 16.sp
            )

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onSave,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981), contentColor = Color.Black),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Save, contentDescription = "", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("حفظ في Room DB", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = onCopy,
                    border = BorderStroke(1.dp, Color(0xFF38BDF8)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Share, contentDescription = "", tint = Color(0xFF38BDF8), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("نسخ التقرير", color = Color(0xFF38BDF8), fontSize = 11.sp)
                }
            }
        }
    }
}

// ==========================================
// Subcomponent 4: BMR Result Card
// ==========================================
@Composable
fun BmrResultCard(
    mifflinBmr: Double,
    harrisBmr: Double,
    weight: Double,
    onSave: () -> Unit,
    onCopy: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A).copy(alpha = 0.95f)),
        border = BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "معدل الأيض الأساسي: $mifflinBmr سعرة/يوم",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 20.sp,
                color = Color(0xFF38BDF8)
            )
            Text(
                text = "معادلة Mifflin-St Jeor القياسية للأيض في وضع الراحة التامة دون أي مجهود.",
                color = Color(0xFF94A3B8),
                fontSize = 11.sp
            )

            HorizontalDivider(color = Color(0xFF334155))

            Text("السعرات اليومية المطلوبة بحسب النشاط البدني (TDEE):", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp)

            val activities = listOf(
                "خامل وقليل الحركة (x1.2)" to (mifflinBmr * 1.2).toInt(),
                "نشاط خفيف (1-3 أيام تمرين) (x1.375)" to (mifflinBmr * 1.375).toInt(),
                "نشاط متوسط (3-5 أيام تمرين) (x1.55)" to (mifflinBmr * 1.55).toInt(),
                "نشاط شاق وعالي الشدة (x1.725)" to (mifflinBmr * 1.725).toInt()
            )

            activities.forEach { (label, cals) ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(label, color = Color(0xFFCBD5E1), fontSize = 11.sp)
                    Text("$cals kcal", color = Color(0xFF10B981), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onSave,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981), contentColor = Color.Black),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Save, contentDescription = "", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("حفظ في Room DB", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = onCopy,
                    border = BorderStroke(1.dp, Color(0xFF38BDF8)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Share, contentDescription = "", tint = Color(0xFF38BDF8), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("نسخ التقرير", color = Color(0xFF38BDF8), fontSize = 11.sp)
                }
            }
        }
    }
}

// ==========================================
// Subcomponent 5: CVD Risk Result Card
// ==========================================
@Composable
fun CvdRiskResultCard(
    riskPercent: Double,
    points: Int,
    onSave: () -> Unit,
    onCopy: () -> Unit
) {
    val riskColor = when {
        riskPercent < 10.0 -> Color(0xFF10B981) // Low risk
        riskPercent < 20.0 -> Color(0xFFF59E0B) // Moderate risk
        else -> Color(0xFFE11D48)               // High risk
    }

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A).copy(alpha = 0.95f)),
        border = BorderStroke(1.dp, riskColor.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "الخطر: $riskPercent%",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 22.sp,
                        color = riskColor
                    )
                    Text(
                        text = "احتمالية حدث وعائي خلال 10 سنوات (النقاط: $points)",
                        color = Color(0xFFCBD5E1),
                        fontSize = 11.sp
                    )
                }

                ClinicalGaugeMeter(
                    fraction = (riskPercent / 35.0).toFloat().coerceIn(0f, 1f),
                    needleColor = riskColor,
                    label = "$riskPercent%"
                )
            }

            // High-Precision Linear Gradient Risk Gauge with Thresholds
            CvdRiskLinearGauge(riskPercent = riskPercent)

            val advice = when {
                riskPercent < 10.0 -> "خطر منخفض: استمرار تعزيز نمط الحياة الصحي والنشاط البدني المنتظم."
                riskPercent < 20.0 -> "خطر متوسط: التفكير في بدء علاج خافض للكوليسترول (ستاتين) وضبط ضغط الدم بحزم."
                else -> "خطر عالي جداً: استشارة قلبية تخصصية، فحص الشرايين التاجية، وخفض مكثف للدهون وضغط الدم."
            }

            Surface(
                shape = RoundedCornerShape(10.dp),
                color = riskColor.copy(alpha = 0.15f),
                border = BorderStroke(1.dp, riskColor.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = advice,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(10.dp)
                )
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onSave,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981), contentColor = Color.Black),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Save, contentDescription = "", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("حفظ في Room DB", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = onCopy,
                    border = BorderStroke(1.dp, Color(0xFF38BDF8)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Share, contentDescription = "", tint = Color(0xFF38BDF8), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("نسخ التقرير", color = Color(0xFF38BDF8), fontSize = 11.sp)
                }
            }
        }
    }
}

// ==========================================
// Custom Semicircular Canvas Gauge Meter
// ==========================================
@Composable
fun ClinicalGaugeMeter(
    fraction: Float,
    needleColor: Color,
    label: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(80.dp, 50.dp),
        contentAlignment = Alignment.BottomCenter
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeW = 8.dp.toPx()
            val arcSize = Size(size.width - strokeW, (size.height * 2) - strokeW)
            val topLeft = Offset(strokeW / 2, strokeW / 2)

            // Background Arc
            drawArc(
                color = Color(0xFF1E293B),
                startAngle = 180f,
                sweepAngle = 180f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeW, cap = StrokeCap.Round)
            )

            // Dynamic Value Arc
            val sweep = 180f * fraction
            drawArc(
                brush = Brush.horizontalGradient(
                    colors = listOf(Color(0xFF10B981), Color(0xFFF59E0B), needleColor)
                ),
                startAngle = 180f,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeW, cap = StrokeCap.Round)
            )

            // Indicator Pin Center
            val angleRad = Math.toRadians((180f + sweep).toDouble())
            val r = (size.width - strokeW) / 2
            val cx = size.width / 2
            val cy = size.height
            val px = cx + (r * cos(angleRad)).toFloat()
            val py = cy + (r * sin(angleRad)).toFloat()

            drawCircle(
                color = Color.White,
                radius = 4.dp.toPx(),
                center = Offset(px, py)
            )
        }

        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            modifier = Modifier.padding(bottom = 2.dp)
        )
    }
}

// =========================================================================
// Advanced Visual Risk Gauge Components (Linear Gradient with Thresholds)
// =========================================================================

data class RiskThreshold(
    val value: Float,
    val label: String
)

data class RiskLegendItem(
    val title: String,
    val rangeText: String,
    val color: Color
)

/**
 * High-precision Linear Gradient Risk Gauge with Canvas threshold tick marks,
 * animated spring pointer needle, Arabic clinical risk badges, and threshold metrics.
 */
@Composable
fun LinearRiskGradientGauge(
    currentValue: Float,
    minValue: Float,
    maxValue: Float,
    unit: String,
    thresholds: List<RiskThreshold>,
    gradientColors: List<Color>,
    activeRiskColor: Color,
    riskBadgeText: String,
    riskLevelSummary: String,
    legendItems: List<RiskLegendItem>,
    modifier: Modifier = Modifier
) {
    // Smooth animated pointer position
    val animatedValue by animateFloatAsState(
        targetValue = currentValue.coerceIn(minValue, maxValue),
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "risk_gauge_anim"
    )

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = Color(0xFF0F172A).copy(alpha = 0.7f),
        border = BorderStroke(1.dp, activeRiskColor.copy(alpha = 0.35f)),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header: Metric Value and Arabic Risk Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Arabic Risk Classification Badge
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = activeRiskColor.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, activeRiskColor.copy(alpha = 0.6f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(activeRiskColor)
                        )
                        Text(
                            text = riskBadgeText,
                            color = activeRiskColor,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }

                // Numerical Readout with Unit
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        text = String.format(java.util.Locale.US, "%.1f", animatedValue),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = unit,
                        fontSize = 11.sp,
                        color = Color(0xFF94A3B8),
                        modifier = Modifier.padding(bottom = 2.dp)
                    )
                }
            }

            // Canvas Gauge: Gradient Track, Threshold Ticks, and Pointer Needle
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                val totalSpan = maxValue - minValue
                fun valueToX(v: Float): Float {
                    val frac = ((v - minValue) / totalSpan).coerceIn(0f, 1f)
                    return frac * size.width
                }

                val barTop = 14.dp.toPx()
                val barHeight = 12.dp.toPx()
                val barBottom = barTop + barHeight
                val barCorner = CornerRadius(barHeight / 2, barHeight / 2)

                // 1. Background Inactive Track
                drawRoundRect(
                    color = Color(0xFF1E293B),
                    topLeft = Offset(0f, barTop),
                    size = Size(size.width, barHeight),
                    cornerRadius = barCorner
                )

                // 2. Full Multi-stop Linear Gradient Track
                drawRoundRect(
                    brush = Brush.horizontalGradient(gradientColors),
                    topLeft = Offset(0f, barTop),
                    size = Size(size.width, barHeight),
                    cornerRadius = barCorner
                )

                // 3. Threshold Tick Marks & Numeric Labels
                val tickPaint = Paint().apply {
                    color = android.graphics.Color.argb(230, 226, 232, 240) // Slate-200
                    textSize = 9.sp.toPx()
                    textAlign = Paint.Align.CENTER
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    isAntiAlias = true
                }

                thresholds.forEach { thresh ->
                    val tickX = valueToX(thresh.value)
                    val tickExt = 3.dp.toPx()

                    // Vertical Threshold Divider Line
                    drawLine(
                        color = Color.White.copy(alpha = 0.85f),
                        start = Offset(tickX, barTop - tickExt),
                        end = Offset(tickX, barBottom + tickExt),
                        strokeWidth = 2.dp.toPx()
                    )

                    // Small Accent Diamond on Threshold
                    drawCircle(
                        color = Color.White,
                        radius = 2.dp.toPx(),
                        center = Offset(tickX, barTop - tickExt)
                    )

                    // Numerical Threshold Label Below Bar
                    val clampedTextX = tickX.coerceIn(16.dp.toPx(), size.width - 16.dp.toPx())
                    drawContext.canvas.nativeCanvas.drawText(
                        thresh.label,
                        clampedTextX,
                        barBottom + 16.dp.toPx(),
                        tickPaint
                    )
                }

                // 4. Animated Indicator Needle Pointer
                val needleX = valueToX(animatedValue)

                // Inverted Triangle Pointer above the bar
                val pointerPath = Path().apply {
                    moveTo(needleX - 6.dp.toPx(), 2.dp.toPx())
                    lineTo(needleX + 6.dp.toPx(), 2.dp.toPx())
                    lineTo(needleX, barTop + 2.dp.toPx())
                    close()
                }
                drawPath(path = pointerPath, color = activeRiskColor)

                // Vertical Glowing Indicator Line through bar
                drawLine(
                    color = Color.White,
                    start = Offset(needleX, barTop),
                    end = Offset(needleX, barBottom),
                    strokeWidth = 3.dp.toPx(),
                    cap = StrokeCap.Round
                )

                // Center Pulsing Indicator Bead
                drawCircle(
                    color = activeRiskColor.copy(alpha = 0.45f),
                    radius = 8.dp.toPx(),
                    center = Offset(needleX, barTop + barHeight / 2)
                )
                drawCircle(
                    color = Color.White,
                    radius = 3.5.dp.toPx(),
                    center = Offset(needleX, barTop + barHeight / 2)
                )
            }

            // Summary Contextual Note
            Text(
                text = riskLevelSummary,
                fontSize = 11.sp,
                color = Color(0xFFCBD5E1),
                lineHeight = 15.sp
            )

            // Risk Zones Legend
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(legendItems) { item ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(item.color)
                        )
                        Text(
                            text = "${item.title}: ${item.rangeText}",
                            fontSize = 10.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// Specialized Metric Gauges
// ==========================================

@Composable
fun BmiRiskLinearGauge(
    bmi: Double,
    modifier: Modifier = Modifier
) {
    val activeColor = when {
        bmi < 18.5 -> Color(0xFF38BDF8) // Underweight: Sky Blue
        bmi < 25.0 -> Color(0xFF10B981) // Normal: Emerald Green
        bmi < 30.0 -> Color(0xFFF59E0B) // Overweight: Amber
        else -> Color(0xFFE11D48)       // Obese: Crimson
    }

    val badgeText = when {
        bmi < 18.5 -> "نقص بالوزن (خطر أيضي منخفض)"
        bmi < 25.0 -> "🛡️ وزن مثالي (خطر قلبي منخفض)"
        bmi < 30.0 -> "⚠️ زيادة وزن (خطر قلبي معتدل)"
        else -> "🚨 سمنة مرضية (خطر وعائي مرتفع)"
    }

    val summary = when {
        bmi < 18.5 -> "الوزن أقل من المعدل الطبيعي، يوصى بفحص التغذية والكتلة العضلية."
        bmi < 25.0 -> "ضمن النطاق الصحي الفسيولوجي الموصى به من منظمة الصحة العالمية (WHO)."
        bmi < 30.0 -> "فوق المعدل الطبيعي؛ يفضل ضبط السعرات اليومية وممارسة تمارين منتظمة."
        else -> "يتطلب استشارة طبية لتقليل مخاطر مقاومة الإنسولين وأمراض الشرايين التاجية."
    }

    LinearRiskGradientGauge(
        currentValue = bmi.toFloat(),
        minValue = 15f,
        maxValue = 40f,
        unit = "kg/m²",
        thresholds = listOf(
            RiskThreshold(18.5f, "18.5"),
            RiskThreshold(25.0f, "25.0"),
            RiskThreshold(30.0f, "30.0")
        ),
        gradientColors = listOf(
            Color(0xFF38BDF8),
            Color(0xFF10B981),
            Color(0xFFF59E0B),
            Color(0xFFE11D48)
        ),
        activeRiskColor = activeColor,
        riskBadgeText = badgeText,
        riskLevelSummary = summary,
        legendItems = listOf(
            RiskLegendItem("نحيف", "<18.5", Color(0xFF38BDF8)),
            RiskLegendItem("طبيعي", "18.5-24.9", Color(0xFF10B981)),
            RiskLegendItem("زيادة", "25-29.9", Color(0xFFF59E0B)),
            RiskLegendItem("سمنة", "≥30", Color(0xFFE11D48))
        ),
        modifier = modifier
    )
}

@Composable
fun CvdRiskLinearGauge(
    riskPercent: Double,
    modifier: Modifier = Modifier
) {
    val activeColor = when {
        riskPercent < 10.0 -> Color(0xFF10B981) // Low Risk: Emerald
        riskPercent < 20.0 -> Color(0xFFF59E0B) // Moderate Risk: Amber
        else -> Color(0xFFE11D48)               // High Risk: Crimson
    }

    val badgeText = when {
        riskPercent < 10.0 -> "🛡️ خطر قلبي منخفض (<10%)"
        riskPercent < 20.0 -> "⚠️ خطر قلبي متوسط (10-20%)"
        else -> "🚨 خطر قلبي مرتفع جداً (>20%)"
    }

    val summary = when {
        riskPercent < 10.0 -> "احتمالية منخفضة للإصابة بجلطة قلبية أو سكتة دماغية خلال 10 سنوات؛ استمر بنمط الحياة الصحي."
        riskPercent < 20.0 -> "احتمالية معتدلة؛ يوصى بمناقشة طبيب القلب حول العلاج الوقائي بالستاتين ومراقبة الضغط الدوري."
        else -> "خطر حرج مرتفع؛ يلزم مراجعة عيادة القلب التخصصية للسيطرة الصارمة على دهون الدم ومؤشرات الالتهاب."
    }

    LinearRiskGradientGauge(
        currentValue = riskPercent.toFloat(),
        minValue = 0f,
        maxValue = 35f,
        unit = "% خلال 10 سنوات",
        thresholds = listOf(
            RiskThreshold(10.0f, "10%"),
            RiskThreshold(20.0f, "20%")
        ),
        gradientColors = listOf(
            Color(0xFF10B981),
            Color(0xFFF59E0B),
            Color(0xFFE11D48)
        ),
        activeRiskColor = activeColor,
        riskBadgeText = badgeText,
        riskLevelSummary = summary,
        legendItems = listOf(
            RiskLegendItem("منخفض", "<10%", Color(0xFF10B981)),
            RiskLegendItem("معتدل", "10-20%", Color(0xFFF59E0B)),
            RiskLegendItem("مرتفع", ">20%", Color(0xFFE11D48))
        ),
        modifier = modifier
    )
}

@Composable
fun EgfrRiskLinearGauge(
    egfr: Double,
    modifier: Modifier = Modifier
) {
    val activeColor = when {
        egfr >= 90.0 -> Color(0xFF10B981) // G1 Normal
        egfr >= 60.0 -> Color(0xFF38BDF8) // G2 Mild
        egfr >= 30.0 -> Color(0xFFF59E0B) // G3 Moderate
        else -> Color(0xFFE11D48)         // G4-G5 Severe/Failure
    }

    val badgeText = when {
        egfr >= 90.0 -> "🛡️ كفاءة كلوية مثالية (G1)"
        egfr >= 60.0 -> "انخفاض وظيفي طفيف (G2)"
        egfr >= 30.0 -> "⚠️ قصور كلوي معتدل (G3)"
        else -> "🚨 قصور كلوي متقدم أو فشل (G4-G5)"
    }

    val summary = when {
        egfr >= 90.0 -> "كفاءة الترشيح الكبيبي سليمة وضمن المعدلات الفسيولوجية الطبيعية."
        egfr >= 60.0 -> "انخفاض طفيف يتطلب فحص الزلال البولي والسيطرة على الضغط الشرياني."
        egfr >= 30.0 -> "تراجع سريري ملحوظ؛ ينبغي مراجعة جرعات الأدوية المصرفة كلوياً."
        else -> "مرحلة حرجة تتطلب متابعة أخصائي أمراض الكلى فوراً ومراقبة كهارل الدم."
    }

    LinearRiskGradientGauge(
        currentValue = egfr.toFloat(),
        minValue = 10f,
        maxValue = 120f,
        unit = "mL/min/1.73m²",
        thresholds = listOf(
            RiskThreshold(30f, "30 (G4)"),
            RiskThreshold(60f, "60 (G3)"),
            RiskThreshold(90f, "90 (G2)")
        ),
        gradientColors = listOf(
            Color(0xFFE11D48),
            Color(0xFFF59E0B),
            Color(0xFF38BDF8),
            Color(0xFF10B981)
        ),
        activeRiskColor = activeColor,
        riskBadgeText = badgeText,
        riskLevelSummary = summary,
        legendItems = listOf(
            RiskLegendItem("حرج (G4-G5)", "<30", Color(0xFFE11D48)),
            RiskLegendItem("معتدل (G3)", "30-60", Color(0xFFF59E0B)),
            RiskLegendItem("خفيف (G2)", "60-90", Color(0xFF38BDF8)),
            RiskLegendItem("طبيعي (G1)", "≥90", Color(0xFF10B981))
        ),
        modifier = modifier
    )
}

@Composable
fun MapRiskLinearGauge(
    mapValue: Double,
    modifier: Modifier = Modifier
) {
    val activeColor = when {
        mapValue < 65.0 -> Color(0xFFE11D48)         // Shock / Hypoperfusion
        mapValue in 65.0..100.0 -> Color(0xFF10B981) // Normal / Optimal
        else -> Color(0xFFF59E0B)                   // Hypertension
    }

    val badgeText = when {
        mapValue < 65.0 -> "🚨 نقص تروية حرج (خطر صدمة)"
        mapValue in 65.0..100.0 -> "🛡️ تروية شريانية مثالية"
        else -> "⚠️ ارتفاع ضغط النضح الوعائي"
    }

    val summary = when {
        mapValue < 65.0 -> "ضغط التروية دون 65 mmHg يهدد تدفق الدم الكلوي والدماغي بشكل إسعافي حرج."
        mapValue in 65.0..100.0 -> "الضغط الوسطي مثالي لضمان تروية شعيرية آمنة دون إجهاد البطين الأيسر."
        else -> "ارتفاع الضغط يزيد من إجهاد جدران الشرايين ويشير لفرط التوتر الشرياني."
    }

    LinearRiskGradientGauge(
        currentValue = mapValue.toFloat(),
        minValue = 45f,
        maxValue = 130f,
        unit = "mmHg",
        thresholds = listOf(
            RiskThreshold(65f, "65 mmHg"),
            RiskThreshold(100f, "100 mmHg")
        ),
        gradientColors = listOf(
            Color(0xFFE11D48),
            Color(0xFF10B981),
            Color(0xFFF59E0B)
        ),
        activeRiskColor = activeColor,
        riskBadgeText = badgeText,
        riskLevelSummary = summary,
        legendItems = listOf(
            RiskLegendItem("نقص تروية", "<65", Color(0xFFE11D48)),
            RiskLegendItem("مثالي", "65-100", Color(0xFF10B981)),
            RiskLegendItem("مرتفع", ">100", Color(0xFFF59E0B))
        ),
        modifier = modifier
    )
}

